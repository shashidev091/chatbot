import { NavLink, Outlet, useNavigate } from "react-router-dom";
import "./About.css";

export const About = () => {
  const navigate = useNavigate();
  return (
    <div className="h-100">
      <h4>This is an about us page</h4>
      <button onClick={() => navigate("/")}>Go back</button>
      <hr />
      <div className="d-flex " style={{height: "100%"}}>
        <div style={{height: "100%", width: "10%"}}>
          <nav className="side-nav" style={{height: "100%"}}>
            <NavLink to={"us"}>About Us</NavLink>
            <NavLink to={"career"}>Career</NavLink>
            <NavLink to={"chat"}>Chat</NavLink>
          </nav>
        </div>
        <div style={{height: "100%", width: "90%"}} className="bgc-salmon">
          <Outlet />
        </div>
      </div>
    </div>
  );
};
