export const AboutUs = () => {
  return (
    <div style={{ height: "100%", width: "100%" }} className="center-element">
      <h3>This is about us Page</h3>
      <iframe
        src="https://webchat.botframework.com/embed/lang-sers-01-bot?s=7R8X5GhnE6Q.lBzwVS3t55cNKVdm5uAeOgfqszTXiF4NWd1AVVkll5I"
        style={{minWidth: "400px", width: "100%", minHeight: "500px"}}
      ></iframe>
    </div>
  );
};
