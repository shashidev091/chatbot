export const AboutCareer = () => {
    return <div style={{height: "100%", width: "100%"}} className="center-element">
        <h3>This is an about page for career.</h3>
    </div>
} 