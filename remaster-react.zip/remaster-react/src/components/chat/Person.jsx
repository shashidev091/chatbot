export const Person = ({text}) => {
    return <div className="person">
        <p>{text}</p>
    </div>
}