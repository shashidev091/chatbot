import axios from "axios";
import { useState } from "react";
import { Ai } from "./Ai";
import "./Chat.css";
import { Person } from "./Person";

const Chat = () => {
  const [inputText, setInputText] = useState("")
  const [messages, setMessages] = useState([
    {
      text: "Hello",
      isAi: true,
    },
  ]);

  useEffect(() => {
    axios.post()
  }, [])

  const sendMessage = () => {
    const messagebody = {
      text: inputText,
      isAi: false,
    };
    setMessages([...messages, messagebody]);
  };

  return (
    <div className="chat-container">
      <div className="chatbox-container">
        <div>
          <input type="text" className="inp" onChange={e => setInputText(e.target.value)}/>
          <button onClick={sendMessage} className="button">
            send
          </button>
        </div>
        <div className="chatbox">
          {messages.map((message, i) =>
            message.isAi ? (
              <Ai text={message.text} key={i + "ai"} />
            ) : (
              <Person text={message.text} key={i + "person"} />
            )
          )}
        </div>
      </div>
    </div>
  );
};

export { Chat };
