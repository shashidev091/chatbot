export const Ai = ({text}) => {
    return <div className="ai">
        <p>{text}</p>
    </div>
}