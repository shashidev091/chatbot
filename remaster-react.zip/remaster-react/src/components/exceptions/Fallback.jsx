export const Fallback = () => {
  return (
    <>
      <div className="container">
        <div className="d-flex justify-content-center">
          <div >
            <h2 className="text-center">Are you lost?</h2>
            <h1 className="text-center">🤣🤣😒😒</h1>
          </div>
        </div>
      </div>
    </>
  );
};
