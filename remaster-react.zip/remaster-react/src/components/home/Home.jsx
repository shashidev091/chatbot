import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

export const Home = () => {
  const navigate = useNavigate();
  const [counter, setCounter] = useState(6);

  useEffect(() => {
    if (counter <= 5) {
      const interval = setInterval(() => {
          if (counter === 1) {
              navigate("about")
              clearInterval(interval)
          }
          setCounter(counter - 1)
      }, 1500)
    }
  }, [counter]);

  const changeRoute = () => {
    setCounter(counter - 1);
  };
  return (
    <div className="container">
      <h3>This is Home Page</h3>
      <h1>{counter - 1}</h1>
      <button className="btn" type="button" onClick={changeRoute}>
        change route
      </button>
    </div>
  );
};
