import "./App.css";
import { Route, Routes } from "react-router-dom";
import { Home } from "./components/home/Home";
import { About } from "./components/about/About";
import { Navbar } from "./components/navbar/Navbar";
import { Fallback } from "./components/exceptions/fallback";
import { AboutCareer } from "./components/about/Inner_components/AboutCareer";
import { AboutUs } from "./components/about/Inner_components/AboutUs";
import { Chat } from "./components/chat/Chat";

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="about" element={<About />}>
          <Route path="career" element={<AboutCareer/>} />
          <Route path="us" element={<AboutUs />} />
          <Route path="chat" element={<Chat />} />
        </Route>
        <Route path="*" element={<Fallback />}></Route>
      </Routes>
    </>
  );
}

export default App;
